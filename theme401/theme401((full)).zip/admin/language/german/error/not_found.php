<?php
// Heading
$_['heading_title']    = 'Seite nicht gefunden!';

// Text
$_['text_not_found']   = 'Die angeforderte Seite konnte leider nicht gefunden werden. Sollte das Problem weiterhin existieren, bitte den Admin davon in Kenntnis setzen.';
?>