<?php
// Heading
$_['heading_title']   = 'Zugriff verweigert!';

// Text
$_['text_permission'] = 'Keine ausreichenden Rechte für den Zugriff auf diese Seite, bitte Admin kontaktieren.';
?>