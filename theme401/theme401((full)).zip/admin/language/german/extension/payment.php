<?php
// Heading
$_['heading_title']      = 'Zahlung';

// Text
$_['text_install']       = 'Installieren';
$_['text_uninstall']     = 'Deinstallieren';

// Column
$_['column_name']        = 'Bezeichnung';
$_['column_status']      = 'Status';
$_['column_sort_order']  = 'Reihenfolge';
$_['column_action']      = 'Aktion';

// Error
$_['error_permission']   = 'Warnung: Sie haben keine Berechtigung, um Zahlungen zu ändern!';
?>