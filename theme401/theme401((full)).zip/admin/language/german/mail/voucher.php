<?php
// Text
$_['text_subject']  = 'Sie haben einen Geschenkgutschein von %s erhalten.';
$_['text_greeting'] = 'Herzlichen Glückwunsch, Ihnen wurde ein Geschenkgutschein in Höhe von %s überreicht!';
$_['text_from']     = 'Dieser Geschenkgutschein wurde Ihnen geschickt von %s';
$_['text_message']  = 'Mit folgender Nachricht';
$_['text_redeem']   = 'Um diesen Geschenkgutschein einzulösen, schreiben Sie diesen Code auf <b>%s</b> und klicken dann auf den Link unten, um den Gutschein für ein Produkt einzulösen. Den Geschenkgutschein Code können Sie im Warenkorb vor der Bestellung eingeben.';
$_['text_footer']   = 'Bitte antworten Sie einfach auf diese E-Mail, falls Sie Fragen haben.';
?>