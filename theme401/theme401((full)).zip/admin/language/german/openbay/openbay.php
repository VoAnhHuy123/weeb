<?php 
$_['heading_title']                     = 'eBay';
$_['text_edit']                         = 'Bearbeiten';
$_['text_install']                      = 'Installieren';
$_['text_uninstall']                    = 'Deinstallieren';
$_['text_enabled']                      = 'Aktiviert';
$_['text_disabled']                     = 'Deaktiviert';
$_['error_category_nosuggestions']      = 'Die vorgeschlagenen Kategorien konnten nicht geladen werden.';
$_['lang_text_success']                 = 'Ihre Änderungen an der eBay Erweiterung wurden gespeichert.';
?>